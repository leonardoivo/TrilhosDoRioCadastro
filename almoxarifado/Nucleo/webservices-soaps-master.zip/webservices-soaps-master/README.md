# WebServerPHP

<p>Respositorio de webservices tipo soap para PHP:</p>

<p>No <a href="http://webservicesoap.azurewebsites.net/app1/">server1</a>: tem um ola mundo simples apenas para introduzir ao estudo do webserices</p>
<p>No <a href="http://webservicesoap.azurewebsites.net/app2/">server2</a>: preencho uma tag select pelo webservice</p>
<p>No <a href="http://webservicesoap.azurewebsites.net/app3/">server3</a>: utilizo eu consumo o webservice dos correios para calcular o preco e estimativa de um encomenda dos correios</p>
<p>No <a href="http://webservicesoap.azurewebsites.net/app4/">server4</a>: populo uma tag select pelo webservice com uma base de dados externa</p>
<p>No <a href="http://webservicesoap.azurewebsites.net/app5/">server5</a>: Um crud simples no qual é possivel inserir, editar, listar, excluir dados de um usuário</p>
<p>No <a href="http://webservicesoap.azurewebsites.net/app6/">server6</a>: Websevice para gerar matricula de um funcionario</p>

Outros webservie de maior complexidade poderam ser inserido no repositorio

<p align="center">
  <img src="soapPHP.png" width="350"/>
  <img src="soapPHP2.png" width="350"/>
</p>
