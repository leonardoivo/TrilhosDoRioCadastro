listar produtos via webservice
e alimentar um select com esta dados