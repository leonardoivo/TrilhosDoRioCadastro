<?php
	echo "Servidor Soap com PHP ";
	include "cliente.php"
?>