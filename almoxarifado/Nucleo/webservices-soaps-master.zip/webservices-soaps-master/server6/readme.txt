Gerar matricula de um empresa fictica
apartir do entredadads
Setopr