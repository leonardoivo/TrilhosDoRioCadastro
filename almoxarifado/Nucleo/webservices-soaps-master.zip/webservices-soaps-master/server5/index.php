<?php

	echo "CRUD-WEBSERVICE SOAP/PHP com a lib nusoap";
	
	echo "<br><a href='pages/criar.php'>Criar </a> "; 
	//echo "<br><a href='pages/editar.php'> Editar  </a> "; 
	//echo "<br><a href='pages/apagar.php'> Excluir </a> "; 
	echo "<br><a href='pages/listar.php'> Listar  </a> "; 

?>