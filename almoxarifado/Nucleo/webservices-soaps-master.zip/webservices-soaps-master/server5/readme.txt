CRUD WEBSERVICE TIPO SOAP EM PHP -

O webservice com quatro operações: 
criação, listagem, edita e exclui 
usuários de uma lista.

O WebService e os dados são armazenados no banco MySql no Azure.