<?php
	 echo "Servidor Soap com PHP: conexao com Banco MySql <br><br>";
	include 'cliente4.php';
?>