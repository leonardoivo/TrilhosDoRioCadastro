WebService que alimenta um SELECT no client 

apartir de uma base de dados externa obtida 
no servidor
