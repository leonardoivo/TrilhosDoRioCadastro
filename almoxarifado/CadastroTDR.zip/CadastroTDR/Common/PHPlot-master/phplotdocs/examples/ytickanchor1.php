<?php
# PHPlot Example: Using a Y tick anchor to force a tick at 0.
# This sets a variable and calls the script directly above.
$set_anchor = 0;
require_once 'ytickanchor.php';
