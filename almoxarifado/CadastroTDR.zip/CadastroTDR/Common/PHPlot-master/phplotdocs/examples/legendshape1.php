<?php
# PHPlot Example: Linepoints plot with legend using shape markers
# This sets a variable and calls the script directly above.
$use_shapes = TRUE;
require_once 'legendshape.php';
