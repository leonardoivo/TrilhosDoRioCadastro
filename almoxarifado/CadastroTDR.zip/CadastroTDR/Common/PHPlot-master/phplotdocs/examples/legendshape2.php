<?php
# PHPlot Example: Line plot with legend using line markers
# This sets variables and calls the script directly above.
$use_shapes = TRUE;
$plot_type = 'lines';
require_once 'legendshape.php';
