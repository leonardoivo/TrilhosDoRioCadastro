<?php
# PHPlot Example: Pie Chart Label Types - Data array
# This is used by several examples. The data is 'altered' for appearance.
$title = 'Energy Production By Source, 2005';
$data = array(
    array('Biomass',        3120.43),
    array('Coal',          23185.20), 
    array('Geotherm.',       343.74),
    array('Hydro',          2703.92),
    array('NGPL',           2334.04),
    array('Nat. Gas',      18574.55), 
    array('Nuclear',        8160.49),
    array('Oil',           10963.63),
);
