<?php
# $Id$
# PHPlot Reference: generate figure showing automatic range adjustment (C)
# See the script named below for details
$case = 'c';
require_once 'fig-autorange-a.php';
