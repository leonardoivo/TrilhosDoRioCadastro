<?php
# $Id$
# PHPlot Reference: generate figure showing automatic range adjustment (B)
# See the script named below for details
$case = 'b';
require_once 'fig-autorange-a.php';
