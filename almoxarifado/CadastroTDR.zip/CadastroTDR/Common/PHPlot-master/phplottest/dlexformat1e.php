<?php
# $Id$
# PHPlot test: Data label extended custom formatting - 1e, stackedbars
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'stackedbars';
$data_type = 'text-data';
$ny = 4;
$max = 5;
require 'dlexformat.php';
