<?php
# $Id$
# PHPlot test: Bar charts - 1
# This is a parameterized test. See the script named at the bottom for details.
$tp = array(
  'suffix' => " (unshaded)",   # Title part 2
  'Shade' => 0,             # Shading: 0 for none or pixels or NULL to omit
  );
require 'bars.php';
