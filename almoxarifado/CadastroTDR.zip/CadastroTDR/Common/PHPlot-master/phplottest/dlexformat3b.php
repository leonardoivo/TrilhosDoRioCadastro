<?php
# $Id$
# PHPlot test: Data label extended custom formatting - 3b, points/error
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'points';
$data_type = 'data-data-error';
$ny = 3;
require 'dlexformat.php';
