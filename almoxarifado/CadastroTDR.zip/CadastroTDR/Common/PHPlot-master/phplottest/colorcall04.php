<?php
# $Id$
# Color callback - squared plot baseline
# See the script named below for details.
$plot_type = 'squared';
require 'colorcall00.php';
