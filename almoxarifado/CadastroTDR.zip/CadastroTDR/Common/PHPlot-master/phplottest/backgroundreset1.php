<?php
# $Id$
# PHPlot test: Background image reset (image bgnd reset, plot bgnd on)
# See the script named at the bottom for details.
$reset_image_background = TRUE;
$reset_plot_area_background = FALSE;
require 'backgroundreset.php';
