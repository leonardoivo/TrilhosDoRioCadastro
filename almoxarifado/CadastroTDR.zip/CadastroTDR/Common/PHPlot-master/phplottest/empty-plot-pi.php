<?php
# $Id$
# PHPlot test - empty plot tests : pie
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'pie';
$data_type = 'text-data-single';
require 'empty-plot.php';
