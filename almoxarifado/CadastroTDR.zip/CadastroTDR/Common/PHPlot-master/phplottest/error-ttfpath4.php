<?php
# $Id$
# Error test - bad TTF font. See error-ttfpath.php for details.
$case = 4;
require 'error-ttfpath.php';
