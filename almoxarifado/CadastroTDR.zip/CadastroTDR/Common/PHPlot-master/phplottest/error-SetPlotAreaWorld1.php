<?php
# $Id$
# Testing PHPlot - Bad data range with SetPlotAreaWorld
# See the script named below for details
$subtitle = 'Xmin>Xmax'; // Subtitle for plot
$spaw = array(200, 20, 20, 200); // Args to SetPlotAreaWorld
require 'error-SetPlotAreaWorld.php';
