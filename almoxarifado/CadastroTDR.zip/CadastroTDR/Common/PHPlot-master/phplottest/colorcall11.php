<?php
# $Id$
# Color callback - data-data-error linepoints plot, baseline
# See the script named below for details.
$plot_type = 'linepoints';
require 'colorcall10.php';
