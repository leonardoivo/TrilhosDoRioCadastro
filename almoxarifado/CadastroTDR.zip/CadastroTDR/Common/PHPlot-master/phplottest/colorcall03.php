<?php
# $Id$
# Color callback - points plot baseline
# See the script named below for details.
$plot_type = 'points';
require 'colorcall00.php';
