<?php
# $Id$
# PHPlot test: Box plot with data variations
# See the script named below for details
$data_colors = 'black';
$point_shape = 'bowtie';
$point_size = 12;
$subtitle = "All black; Outliers use bowtie (12px)";
require 'boxplot.php';
