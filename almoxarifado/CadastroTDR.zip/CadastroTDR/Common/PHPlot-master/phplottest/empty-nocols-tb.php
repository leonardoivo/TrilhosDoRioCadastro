<?php
# $Id$
# PHPlot test - empty plot with no Y values at all, thinbarline
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'thinbarline';
$data_type = 'data-data';
require 'empty-nocols.php';
