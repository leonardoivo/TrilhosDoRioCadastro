<?php
# $Id$
# PHPlot test - empty plot tests : ohlc
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'ohlc';
$data_type = 'data-data';
require 'empty-plot.php';
