<?php
# $Id$
# PHPlot test: areas+borders - stackedarea, borders
# This is a parameterized test. See the script named at the bottom for details.
$tp = array(
  'plot_type' => 'stackedarea',
  'draw_borders' => TRUE,
  );
require 'areaborders00.php';

