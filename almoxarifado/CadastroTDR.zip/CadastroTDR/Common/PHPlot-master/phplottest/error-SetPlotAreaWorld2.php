<?php
# $Id$
# Testing PHPlot - Bad data range with SetPlotAreaWorld
# See the script named below for details
$subtitle = 'Ymin>Ymax'; // Subtitle for plot
$spaw = array(20, 200, 200, 20); // Args to SetPlotAreaWorld
require 'error-SetPlotAreaWorld.php';
