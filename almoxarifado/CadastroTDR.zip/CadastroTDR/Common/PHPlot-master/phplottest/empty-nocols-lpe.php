<?php
# $Id$
# PHPlot test - empty plot with no Y values at all, linepoints error plot
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'linepoints';
$data_type = 'data-data-error';
require 'empty-nocols.php';
