<?php
# $Id$
# PHPlot test: areas+borders - squaredarea, borders
# This is a parameterized test. See the script named at the bottom for details.
$tp = array(
  'plot_type' => 'squaredarea',
  'draw_borders' => TRUE,
  );
require 'areaborders00.php';

