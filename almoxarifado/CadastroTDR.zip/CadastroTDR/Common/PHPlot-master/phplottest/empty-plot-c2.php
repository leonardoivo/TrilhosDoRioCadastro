<?php
# $Id$
# PHPlot test - empty plot tests : candlesticks2
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'candlesticks2';
require 'empty-plot.php';
