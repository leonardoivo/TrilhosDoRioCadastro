<?php
# $Id$
# PHPlot test: areas+borders - area, borders, color, raised X
# This is a parameterized test. See the script named at the bottom for details.
$tp = array(
  'draw_borders' => TRUE,
  'border_colors' => TRUE,
  'x_axis' => 10,
  );
require 'areaborders00.php';

