<?php
# $Id$
# Color callback - data-data-error points plot, baseline
# See the script named below for details.
$plot_type = 'points';
require 'colorcall10.php';
