<?php
# $Id$
# PHPlot test: Data label extended custom formatting - 2g, thinbarline (vert)
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'thinbarline';
$data_type = 'data-data';
$nx = 15;
$ny = 1;
$dvls = False; // This plot & data type does not do Data Value Labels.
require 'dlexformat.php';
