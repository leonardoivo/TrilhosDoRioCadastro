<?php
# $Id$
# PHPlot test: Box plot - tuning parameters
# This is a parameterized test. See the script named at the bottom for details.
$tp = array(
  'subtitle' => 'Baseline',    # Title part 2
  'n_points' => 40,            # Number of data points
  );
require 'boxplot-tune.php';
