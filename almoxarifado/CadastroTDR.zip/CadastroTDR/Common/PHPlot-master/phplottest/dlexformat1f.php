<?php
# $Id$
# PHPlot test: Data label extended custom formatting - 1f, horiz. bars
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'bars';
$data_type = 'text-data-yx';
$ny = 3;
require 'dlexformat.php';
