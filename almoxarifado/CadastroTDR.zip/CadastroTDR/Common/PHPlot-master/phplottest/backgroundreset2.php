<?php
# $Id$
# PHPlot test: Background image reset (image bgnd on, plot bgnd reset)
# See the script named at the bottom for details.
$reset_image_background = FALSE;
$reset_plot_area_background = TRUE;
require 'backgroundreset.php';
