<?php
# $Id$
# Color callback - lines plot baseline
# See the script named below for details.
$plot_type = 'lines';
require 'colorcall00.php';
