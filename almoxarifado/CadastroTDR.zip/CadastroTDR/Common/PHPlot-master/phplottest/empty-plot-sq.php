<?php
# $Id$
# PHPlot test - empty plot tests : squared
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'squared';
$data_type = 'data-data';
require 'empty-plot.php';
