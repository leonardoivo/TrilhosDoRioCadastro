<?php
# $Id$
# PHPlot test - empty plot with no Y values at all, stackedsquaredarea plot
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'stackedsquaredarea';
$data_type = 'data-data';
require 'empty-nocols.php';
