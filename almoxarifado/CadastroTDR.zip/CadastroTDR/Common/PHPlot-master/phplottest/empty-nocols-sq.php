<?php
# $Id$
# PHPlot test - empty plot with no Y values at all, squared plot
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'squared';
$data_type = 'text-data';
require 'empty-nocols.php';
