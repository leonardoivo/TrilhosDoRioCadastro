<?php
# $Id$
# PHPlot test - empty plot tests : stackedbars
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'stackedbars';
require 'empty-plot.php';
