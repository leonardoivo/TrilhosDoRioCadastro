<?php
# $Id$
# PHPlot test - empty plot with no Y values at all, bubbles plot
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'bubbles';
$data_type = 'data-data-xyz';
require 'empty-nocols.php';
