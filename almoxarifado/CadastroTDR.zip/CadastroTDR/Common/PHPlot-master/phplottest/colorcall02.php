<?php
# $Id$
# Color callback - linepoints plot baseline
# See the script named below for details.
$plot_type = 'linepoints';
require 'colorcall00.php';
