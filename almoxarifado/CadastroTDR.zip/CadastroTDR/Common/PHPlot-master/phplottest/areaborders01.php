<?php
# $Id$
# PHPlot test: areas+borders - area, borders
# This is a parameterized test. See the script named at the bottom for details.
$tp = array(
  'draw_borders' => TRUE,
  );
require 'areaborders00.php';

