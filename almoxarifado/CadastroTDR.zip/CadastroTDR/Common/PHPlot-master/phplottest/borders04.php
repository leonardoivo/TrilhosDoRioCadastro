<?php
# $Id$
# Plot and image borders - case 04
# This is a parameterized test. See the script named at the bottom for details.
$tp = array(
  'plotborder' => 'none',     # Plot border type or NULL to skip
  'pbcolor' => 'red',        # Grid color, used for plot border
  );
require 'borders.php';
