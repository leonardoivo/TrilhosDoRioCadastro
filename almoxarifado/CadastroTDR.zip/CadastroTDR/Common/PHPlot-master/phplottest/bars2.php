<?php
# $Id$
# PHPlot test: Bar charts - 2
# This is a parameterized test. See the script named at the bottom for details.
$tp = array(
  'suffix' => " (deep shading)",   # Title part 2
  'Shade' => 20,            # Shading: 0 for none or pixels or NULL to omit
  );
require 'bars.php';
