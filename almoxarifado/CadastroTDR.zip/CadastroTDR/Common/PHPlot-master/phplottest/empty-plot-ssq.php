<?php
# $Id$
# PHPlot test - empty plot tests : stackedsquaredarea
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'stackedsquaredarea';
$data_type = 'data-data';
require 'empty-plot.php';
