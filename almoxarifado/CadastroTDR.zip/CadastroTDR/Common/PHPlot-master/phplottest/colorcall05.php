<?php
# $Id$
# Color callback - stackedbars plot baseline
# See the script named below for details.
$plot_type = 'stackedbars';
require 'colorcall00.php';
