<?php
# $Id$
# PHPlot test - empty plot tests : area
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'area';
$data_type = 'data-data';
require 'empty-plot.php';
