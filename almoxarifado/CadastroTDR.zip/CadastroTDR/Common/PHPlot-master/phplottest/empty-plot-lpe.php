<?php
# $Id$
# PHPlot test - empty plot tests : linepoints error
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'linepoints';
$data_type = 'data-data-error';
require 'empty-plot.php';
