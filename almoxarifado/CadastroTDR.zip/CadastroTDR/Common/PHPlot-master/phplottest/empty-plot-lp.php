<?php
# $Id$
# PHPlot test - empty plot tests : linepoints
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'linepoints';
require 'empty-plot.php';
