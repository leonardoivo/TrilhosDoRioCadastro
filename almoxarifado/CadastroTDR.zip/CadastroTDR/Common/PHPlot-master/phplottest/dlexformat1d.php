<?php
# $Id$
# PHPlot test: Data label extended custom formatting - 1d, bars
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'bars';
$data_type = 'text-data';
$ny = 2;
require 'dlexformat.php';
