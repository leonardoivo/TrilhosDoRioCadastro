<?php
# $Id$
# PHPlot test: areas+borders - area, unordered data, borders, colors
# This is a parameterized test. See the script named at the bottom for details.
$tp = array(
  'mixed_data' => TRUE,
  'draw_borders' => TRUE,
  'border_colors' => TRUE,
  );
require 'areaborders00.php';

