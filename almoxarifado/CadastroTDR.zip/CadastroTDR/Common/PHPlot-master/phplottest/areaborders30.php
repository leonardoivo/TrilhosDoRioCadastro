<?php
# $Id$
# PHPlot test: areas+borders - stackedsquaredarea
# This is a parameterized test. See the script named at the bottom for details.
$tp = array(
  'plot_type' => 'stackedsquaredarea',
  );
require 'areaborders00.php';

