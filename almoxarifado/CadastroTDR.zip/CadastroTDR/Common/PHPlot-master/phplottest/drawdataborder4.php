<?php
# $Id$
# PHPlot test - SetDrawDrawBorders (PHPlot >= 6.0) - case 4
# This is a parameterized test. See the script named at the bottom for details.
$tp = array(
  'draw_borders' => True,   # SetDrawDataBorders: NULL to not call, True, False
  );
require 'drawdataborder.php';
