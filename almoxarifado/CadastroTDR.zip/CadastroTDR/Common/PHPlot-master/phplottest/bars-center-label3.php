<?php
# $Id$
# PHPlot test: Bar Chart Labels Centering - 3
# This is a parameterized test. See the script named at the bottom for details.
$tp = array(
  'suffix' => "",           # Title part 2
  'ND' => 4,                # Number of data rows
  'NB' => 3,                # Number of bars per group
  'Shade' => 0,             # Shading
  );
require 'bars-center-label.php';
