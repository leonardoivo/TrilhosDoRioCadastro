<?php
# $Id$
# PHPlot test: Data label extended custom formatting - 1b, linepoints
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'linepoints';
$data_type = 'data-data';
$ny = 2;
require 'dlexformat.php';
