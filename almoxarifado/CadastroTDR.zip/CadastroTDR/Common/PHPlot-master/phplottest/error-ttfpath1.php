<?php
# $Id$
# Error test - bad TTF font. See error-ttfpath.php for details.
$case = 1;
require 'error-ttfpath.php';
