<?php
# $Id$
# Color callback - thinbarline plot baseline
# See the script named below for details.
$plot_type = 'thinbarline';
require 'colorcall00.php';
