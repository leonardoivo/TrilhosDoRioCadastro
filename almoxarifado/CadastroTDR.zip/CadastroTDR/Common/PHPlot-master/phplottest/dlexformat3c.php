<?php
# $Id$
# PHPlot test: Data label extended custom formatting - 3c, linepoints/error
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'linepoints';
$data_type = 'data-data-error';
$ny = 1;
require 'dlexformat.php';
