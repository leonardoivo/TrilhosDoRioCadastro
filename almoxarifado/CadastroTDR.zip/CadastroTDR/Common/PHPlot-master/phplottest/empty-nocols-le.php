<?php
# $Id$
# PHPlot test - empty plot with no Y values at all, lines error plot
# This is a parameterized test. See the script named at the bottom for details.
$plot_type = 'lines';
$data_type = 'data-data-error';
require 'empty-nocols.php';
