<?php
# $Id$
# Color callback - horizontal bar plot baseline
# See the script named below for details.
$plot_type = 'bars';
$data_type = 'text-data-yx';
require 'colorcall00.php';
