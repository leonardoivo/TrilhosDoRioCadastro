<?php
namespace TrilhosDorioCadastro\DTO{
class PerfilDTO{
public    $id_perfil;
public    $nome_perfil;
public    $tipo_acesso;


}

}
?>