<?php
namespace TrilhosDorioCadastro\DTO{

class AcessoJV_DTO{
    public      $id_perfil;
    public      $nome_perfil;
    public      $tipo_acesso;
    public      $id_usuario;
    public      $cpf;
    public      $nome;
    public      $email;
    public      $login;
    public      $senha;
    public      $celular;
    public      $situacao;
    public      $sobrenome;
    }
}
?>