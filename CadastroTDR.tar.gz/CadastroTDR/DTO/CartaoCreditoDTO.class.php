<?php

namespace TrilhosDorioCadastro\DTO{
class CartaoCreditoDTO{
public     $idCartao; 
public     $bandeira;
public     $numeroCartao;
public     $Titular;
public     $dataDeValidade; 
public     $codigo;
public     $id_associado;

}

}
?>