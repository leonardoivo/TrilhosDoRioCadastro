<?php

namespace TrilhosDorioCadastro\DTO{
class BancoDTO{
public     $idbanco;
public     $nomebanco;
public     $codigobancario;

}

}
?>