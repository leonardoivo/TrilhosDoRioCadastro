<?php
namespace TrilhosDorioCadastro\DTO{
class  ContaDTO{
public   $idconta; 
public   $tipoconta; 
public   $idagencia;
public   $numeroconta; 
public   $digitoconta; 
public   $id_associado;



}
}

?>