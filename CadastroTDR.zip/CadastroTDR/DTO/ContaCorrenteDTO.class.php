<?php
namespace TrilhosDorioCadastro\DTO{}

?>