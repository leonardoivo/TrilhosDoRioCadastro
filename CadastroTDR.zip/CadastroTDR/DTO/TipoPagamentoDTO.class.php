<?php
namespace TrilhosDorioCadastro\DTO{
class TipoPagamentoDTO{

public      $idTipoPagamento; 
public      $nomeTipoPag; 
public      $descricao;

}
}
?>