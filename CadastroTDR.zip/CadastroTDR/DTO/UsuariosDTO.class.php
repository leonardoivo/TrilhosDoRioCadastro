<?php

namespace TrilhosDorioCadastro\DTO{
class UsuariosDTO{
public      $id_usuario;
public      $cpf;
public      $nome;
public      $id_perfil;
public      $email;
public      $login;
public      $senha;
public      $celular;
public      $situacao;
public      $sobrenome;




}
}
?>