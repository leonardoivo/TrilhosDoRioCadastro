<?php
namespace TrilhosDorioCadastro\DTO{
class OrigemAssociadoDTO{
public   $id_origem;
public   $Origem;


}

}
?>