<?php

namespace TrilhosDorioCadastro\DTO{
class AgenciaBancariaDTO{
public   $idAgencia;
public   $nomeagencia; 
public   $numeroagencia;
public   $idbanco;

}


}
?>