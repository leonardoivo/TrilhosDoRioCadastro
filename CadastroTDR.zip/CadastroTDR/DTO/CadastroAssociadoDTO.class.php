<?php

namespace TrilhosDorioCadastro\DTO{
class CadastroAssociadoDTO{
public      $id_associado; 
public      $nome; 
public      $sobrenome;
public      $data_De_nascimento;
public      $email;
public      $telefone; 
public      $id_origem; 
public      $endereco; 
public      $cep; 
public      $Bairro; 
public      $Cidade;
public      $Estado; 
public      $data_De_cadastro; 
public      $pais; 
public      $data_De_desligamento; 
public      $forma_de_doacao; 
public      $numero; 
public      $complemento; 
public      $cpf; 
public      $interesses; 
public      $naturalidade;

}


}
?>