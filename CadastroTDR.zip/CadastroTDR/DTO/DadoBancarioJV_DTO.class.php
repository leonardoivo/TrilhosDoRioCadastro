<?php
namespace TrilhosDorioCadastro\DTO{
class DadoBancarioJV_DTO{
public          $idconta;
public          $codigobancario;
public          $nomebanco;
public          $numeroagencia;
public          $tipoconta;
public          $numeroconta;
public          $digitoconta;

}

}

?>